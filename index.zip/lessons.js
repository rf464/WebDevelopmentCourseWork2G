
    let lessons = [
        {
            "id": 1001,
            "spacesLeft": 5,
            "image": "./images/maths.png",
            "subject": "Math",
            "location": "London",
            "price": "Price: £100",
            "numberOfSpaces": "Number of spaces: ",
            "rating": 3
        },
        {
            "id": 1002,
            "spacesLeft": 5,
            "image": "./images/english.png",
            "subject": "English",
            "location": "LiverPool",
            "price": "Price: £110",
            "numberOfSpaces": "Number of spaces: ",
            "rating": 3
        },
        {
            "id": 1003,
            "spacesLeft": 5,
            "image": "./images/french.png",
            "subject": "French",
            "location": "Watford",
            "price": "Price: £90",
            "numberOfSpaces": "Number of spaces: ",
            "rating": 4
        },
        {
            "id": 1004,
            "spacesLeft": 5,
            "image": "./images/geography.png",
            "subject": "Geogrpahy",
            "location": "Birmingham",
            "price": "Price: £100",
            "numberOfSpaces": "Number of spaces: ",
            "rating": 2
        },
        {
            "id": 1005,
            "spacesLeft": 5,
            "image": "./images/history.png",
            "subject": "History",
            "location": "London",
            "price": "Price: £110",
            "numberOfSpaces": "Number of spaces: ",
            "rating": 3
        },
        {
            "id": 1006,
            "spacesLeft": 5,
            "image": "./images/IT.png",
            "subject": "IT",
            "location": "London",
            "price": "Price: £120",
            "numberOfSpaces": "Number of spaces: ",
            "rating": 4
        },
        {
            "id": 1007,
            "spacesLeft": 5,
            "image": "./images/music.png",
            "subject": "Music",
            "location": "Luton",
            "price": "Price: £120",
            "numberOfSpaces": "Number of spaces: ",
            "rating": 3
        },
        {
            "id": 1008,
            "spacesLeft": 5,
            "image": "./images/science.png",
            "subject": "Science",
            "location": "London",
            "price": "Price: £100",
            "numberOfSpaces": "Number of spaces: ",
            "rating": 3
        },
        {
            "id": 1009,
            "spacesLeft": 5,
            "image": "./images/spanish.png",
            "subject": "Spanish",
            "location": "Watford",
            "price": "Price: £80",
            "numberOfSpaces": "Number of spaces: ",
            "rating": 3
        },
        {
            "id": 1010,
            "spacesLeft": 5,
            "image": "./images/sports.png",
            "subject": "Sports",
            "location": "Liverpool",
            "price": "Price: £80",
            "numberOfSpaces": "Number of spaces: ",
            "rating": 4
        }
    ]
